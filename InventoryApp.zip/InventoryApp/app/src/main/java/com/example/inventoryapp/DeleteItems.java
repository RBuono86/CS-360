package com.example.inventoryapp;

import androidx.appcompat.app.AlertDialog;

/**
 * Delete Items Alert Dialog java code.
 * <p>
 * The DeleteItems class include the functionality to build the
 * alert dialog to delete all the items records in the database.
 * <p>
 * This is class is called from the ItemsListActivity class.
 *
 * @author	Richard Buono <i>richard.buono@snhu.edu</i>
 * @course	CS-360 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */

public class DeleteItems {

    public static AlertDialog doubleButton(final ItemsListActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.delete_title)
                .setIcon(R.drawable.delete_all_items)
                .setCancelable(false)
                .setMessage(R.string.delete_msg)
                .setPositiveButton(R.string.delete_dialog_yes_button, (dialog, arg1) -> {
                    ItemsListActivity.YesDeleteItems();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.delete_dialog_no_button, (dialog, arg1) -> {
                    ItemsListActivity.NoDeleteItems();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}
