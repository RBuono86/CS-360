package com.example.inventoryapp;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

/**
 * SMS Notification Alert Dialog java code.
 * <p>
 * The AD_SMSNotification class include the functionality to build the
 * alert dialog to enable or disable the SMS notifications when an item
 * quantity id zero.
 * <p>
 * This is class is called from the ItemsListActivity class.
 *
 * @author	Richard Buono <i>richard.buono@snhu.edu</i>
 * @course	CS-360 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */

public class SMSNotification {

    public static AlertDialog doubleButton(final ItemsListActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.sms_title)
                .setIcon(R.drawable.sms_notification)
                .setCancelable(false)
                .setMessage(R.string.sms_msg)
                .setPositiveButton(R.string.sms_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                    ItemsListActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.sms_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                    ItemsListActivity.DenySendSMS();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}